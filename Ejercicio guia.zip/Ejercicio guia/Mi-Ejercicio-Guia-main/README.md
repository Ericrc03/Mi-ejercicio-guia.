# Mi-Ejercicio-Guia

Version con conexión 
Version con concurrencia